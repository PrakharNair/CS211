#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//Global variables
int cSize = 0; 
int assoc = 0; 
int bSize = 0;
char * binary; 
char * digits; 
int nSet = 0; 
char * tag; 
char * fText; 
FILE * file;
int aHit = 0; 
int aMiss = 0; 
int aRead = 0; 
int aWrite = 0;
int bHit = 0; 
int bMiss = 0; 
int bRead = 0; 
int bWrite = 0; 

typedef struct Line {
    char* tag;
    int index;
    char* off;
} Line;


typedef struct Queue {
    struct Queue * next;
    struct Queue * prev;
    Line * line;
} Queue;


typedef struct Cache {
    Queue * q;
} Cache;

void printCache(); 
void addToCache(Cache * table, char * num, Line * tmp); 
void insertCache(Cache * t1, Cache * t2); 
void error(); 
bool PowerOfTwo(int x);
int max(int a, int b); 
int toInt(char * adr); 
void confirm(char ** userInput); 
char * binConvert(char * hVal); 
void parse(Cache * t1, Cache * t2, char * val); 
Line * bitInfo(char * binary, bool a0);
char * zeroAddress(char * binary); 
void navigate(char * info, Cache * t1, Cache * t2); 
	
