#include <string.h>
#include <stdio.h>
#include "nCr.h"
#include <malloc.h>
#include <stdlib.h>
#include <sys/time.h>

int main (int argc, char ** argv)
{
	struct timeval start, end;
	gettimeofday(&start, NULL);
	if (argc != 2)
	{
		printf("Too many/too few arguements!\n");
		return 0;
	}
	char * str = (char *)malloc(sizeof(argv[1]));
	strcpy(str, argv[1]);
	char helpflag[3] = "-h\0";
	int cmp = strcmp(str,helpflag);
	if (cmp == 0)
	{
		printf("Usage: formula <positive integer>\n");
		return 0;
	}
	int input = atoi(str);
	int i = 0;
	if (input > 12)
	{
		printf("32 Bit factorial can only handle 12! and less.\n");
		return 0;
	}
	int coeff;
	for (; i <= input; i++)
	{
		if (i == 0)
		{
			printf("1 +");
			continue;
		}
		
		coeff = nCr(input, i);
		if (i == input)
		{
			printf(" %d*x^%d",coeff, i);
			break;
		}
		else
		{
			printf(" %d*x^%d +", coeff, i);
		}
	}
	printf("\n");
	gettimeofday(&end, NULL);
	printf("Time Required: %ld microseconds.\n", ((end.tv_sec*1000000 + end.tv_usec)-(start.tv_sec*1000000 + start.tv_usec)));
	return 0;
}
