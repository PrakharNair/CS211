#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int add(int num1, int num2) {	
	return num1 + num2;
}

int fib (int fibnum, int * array)  {
	if (array[fibnum] == -1) {
		if (fibnum == 1) {
			array[1] = 1;
		}
		else if (fibnum == 0) {
			array[0] = 0;
		}
		else {
			if (array[fibnum - 1] == -1) {
				array[fibnum - 1] = fib(fibnum - 1, array);
			}
			if (array[fibnum - 2] == -1) {
				array[fibnum - 2] = fib(fibnum - 2, array);
			}
			array[fibnum] = add(array[fibnum-1], array[fibnum-2]);
		}
	}
	return array[fibnum];
}
	

int main (int agrc, char ** argv) {
	int fibnum = atoi(argv[1]);
	if (fibnum > 46) {
		printf("The %d fib number will not fit into a 32 bit signed int \n", fibnum);
		return 0;
	}
	int array[47];
	int i = 0;

	while(i <= 46) {
		array[i] = -1;
		i++; 
	}
	int value = fib(fibnum, array);
	printf("The %d fib number is: %d\n", fibnum, value);
	return 0;
}
