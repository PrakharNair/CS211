#ifndef _MYSTERY_H_
#define _MYSTERY_H_

int add (int num1, int num2);

int fibonacci(int n, int * array);

#endif
