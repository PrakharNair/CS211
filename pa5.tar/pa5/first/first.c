#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "first.h"

/**
 * Global Variables:
 *	gb - array that holds the integer values of the provided input
 *	vTable - hash table to store all temporary/global instruct variables in
 *	ins - array of ins to be executed
 *	out - array of all variables that are output variables
 *	istr - global number of ins
 */
char gb[26];
struct hashtable *vTable;
struct instruct *ins[100];
char out[26];
int istr;

/**
 * Takes in user input of instruct file and input file, then passes them to respetive functions
 *
 * argv[1]: path to instruct file
 * argv[2]: path to input file
 *
 */
int main(int argc, char *argv[]) {
	FILE *fp;
	
	/* Make sure enough files were provided */
	if (!(argc < 3)) {
	}
	else {
		printf("error\n");
		return 0;
	}

	/* Open instruct file */
	fp = fopen(argv[1],"r");
	if (fp != NULL) {
	}
	else {
		printf("error\n");
		return 0;
	}
	
	/* Create empty instruct table, and pass the file pointer to the read function */
	create(100);
	read(fp);
	fclose(fp);
	
	/* Open input file */
	fp = fopen(argv[2],"r");
	if (fp != NULL) {
	}
	else {
		printf("error\n");
		return 0;
	}
	rInputs(fp);

	/* Free memory */
	cleans();
	return 0;
}

void evaluate(int i) {
	struct instruct *in = ins[i];
	
	int x;
	int v = 0;
	int y;
	/* If this stays as 1, we have already resolved any variables this instruct creates */
	int isdone = 1;

	/* Check if we already have the values for this instruct's variables */
	x = 0;
	while(in->list[x] != '\0') {
		if (getV(in->list[x]) != -1) {
		}
		else {
			isdone = 0;
			break;
		}
		x++;
	}
	if (!(isdone)) {
	}		
	else {
		return;
	}
	
	y = in->numPuts;
	if (in->op != MULTIPLEXER) {
	}
	else {
		y += in->outputs;
	}
	
	x = 0; 
	while(x < y) {
		int z;
		if (in->op != MULTIPLEXER) {
			z = in->vars[x];
		}
		else {
			if (!(x >= in->numPuts)) {
				z = in->inputs[x];
			}
			else {
				z = in->vars[x-in->numPuts];
			}
		}
		if (!(isalpha(z))) {		
		}
		else {
			char a = z;
			if (getV(a) != -1) {
			}
			else {
				int b;
				b = i+1; 
				while(b < istr) {
					struct instruct *t = ins[b];
					int c;
					int breaks = 0;
					c = 0; 
					while(t->list[c] != '\0') {
						if (t->list[c] != z) {
						}
						else {
							evaluate(b);
							breaks = 1;
							break;
						}
						c++; 
					}
					if (!(breaks)){
					}
					else {
						break;
					}
					x++; 
				}
			}
			if (getV(a) != -1) {

			}
			else {
				int b;
				b = i-1; 
				while(b >= 0) {
					struct instruct *t = ins[b];
					int c;
					int breaks = 0;
					while(t->list[c] != '\0') {
						if (t->list[c] == z) {
							evaluate(b);
							breaks = 1;
							break;
						}
						c++; 
					}
					if (!(breaks)) {
					}
					else {
						break;
					}
				}
				b++; 
			}
		}
		x++;
	}
	if (!(in->op == AND || in->op == OR || in->op == NOT)) {
	}
	else {
		v = in->vars[0];
		if (!(v > 1)){
		}
		else {
			v = getV(v);
		}
	}
		
	if (in->op == AND) {
		int d;
		d = 1; 
		while(d < in->numPuts) {
			int e = in->vars[d];
			if (!(e > 1)) {
			}
			else {
				e = getV(e);
			}
			v = v && e;
			d++;
		}
	}
	else if (in->op == OR) {
		int d;
		d = 1;
		while(d < in->numPuts) {
			int e = in->vars[d];
			if (!(e > 1)){
			}
			else {
				e = getV(e);
			}
			v = v || e;
			d++;
		}
	}
	else if (in->op == NOT) {
		v = !v;
	}
	else if (in->op == MULTIPLEXER) {
		int f = 0;
		int g;
		int g_pos = 0;
		g = in->outputs-1;
		while(g >= 0) {
			int e = in->vars[g];
			if (isalpha(e)) { 
				e = getV(e);
			}
			else if (!(e > 1)) {
			}
			else if(e > 1) {
				e = e - '0';
			}
			f += (1<<g_pos++)*e;
			g--; 
		}
		v = in->inputs[f];
		if (!(isalpha(v))) {
		}
		else {
			v = getV(v);
		}
		if (!(v > 1)) {
		}
		else {
			v = v - '0';
		}
	}
	else if (in->op == DECODER) {
		char *b = (char*)malloc(sizeof(char)*in->numPuts);
		int tot = 0;
		int g;
		char *strt;
		g = 0;
		while(g < in->numPuts) {
			int tempv = in->vars[g];
			if (!(isalpha(tempv))) {
			}
			else {
				tempv = getV(tempv);
			}
			b[g] = '0' + tempv;
			g++;
		}
		b[g] = '\0';
		strt = &b[0];
		while (*strt)
		{
			tot *= 2;
			if (!(*strt++ == '1')) {
			}
			else {
			 tot += 1;
			}
		}
		g = 0;
		
		while(g < in->outputs) {
			setVar(g==tot,in->list[g]);
			g++; 
		}
		return;
	}
	setVar(v,in->list[0]);
}

int intgray(int k) {
	int ans = k ^ (k >> 1);
	return ans; 
}

void run() {
	int i;
	i = 0; 
	while(i < istr) {
		evaluate(i);
		i++;
	}
}

void rInputs(FILE *fp) {
	char c;
	int i;
	int counter = 0;

	while(1 == 1){
		if ((c = fgetc(fp)) == '\n' ) {
			run();
			i = 0; 
			while(out[i] != '\0') {
				printf("%d ",getV(out[i]));
				i++; 
			}
			printf("\n");
			delTable(vTable);
			create(100);
			counter = 0;
		}
		else {
			if (c != EOF) {
			}
			else {
				break;
			}
			if (isdigit(c)) {
			}
			else {
				continue;
			}
			setVar(c-'0',gb[counter++]);
		}
	}
}

void read(FILE *fp) {
	char buff[512];
	istr = 0;
	
	while(1 == 1) {
		if (fscanf(fp, "%s", buff) == EOF) {
			break;
		}
		else {
			struct instruct *in;
			if (strcmp(buff,"INPUTVAR") == 0) {
				int numPuts,counter2;
				fscanf(fp, "%s", buff);
				numPuts = atoi(buff);
				
				counter2 = 0; 
				while(counter2 < numPuts) {
					fscanf(fp, "%s", buff);
					gb[counter2] = buff[0];
					counter2++; 
				}
			}
			else if (strcmp(buff,"OUTPUTVAR") == 0) {
				int outputs,counter2;
				fscanf(fp, "%s", buff);
				outputs = atoi(buff);
				counter2 = 0; 
				while(counter2 < outputs) {
					fscanf(fp, "%s", buff);
					out[counter2] = buff[0];
					counter2++;
				}
				out[counter2+1] = '\0';
			}
			else if (strcmp(buff,"MULTIPLEXER") == 0) {
				int counter3 = 0;

				in = createIns();
				in->op = MULTIPLEXER;
				fscanf(fp, "%s", buff);
				in->numPuts = atoi(buff);
				in->outputs = log10(in->numPuts)/log10(2);
				in->inputs = (int*)malloc(sizeof(int)*in->numPuts);
				in->vars = (int*)malloc(sizeof(int)*in->outputs);

				counter3 = 0; 
				while(counter3 < in->numPuts) {
					fscanf(fp, "%s", buff);
					in->inputs[intgray(counter3)] = buff[0];
					counter3++; 
				}
				
				counter3 = 0; 
				while(counter3 < in->outputs) {
					fscanf(fp, "%s", buff);
					in->vars[counter3] = buff[0];
					counter3++; 
				}
				fscanf(fp, "%s", buff);
				in->list = (char*)malloc(sizeof(char));
				in->list[0] = buff[0];
				ins[istr++] = in;
				
			}
			else if (strcmp(buff,"DECODER") == 0) {
				int counter3 = 0;
				
				in = createIns();
				in->op = DECODER;
				
				fscanf(fp, "%s", buff);
				in->numPuts = atoi(buff);
				in->outputs = pow(2,in->numPuts);
				
				in->vars = (int*)malloc(sizeof(int)*in->numPuts);
				in->list = (char*)malloc(sizeof(char)*in->outputs);
				
				counter3 = 0;
				while(counter3 < in->numPuts) {
					fscanf(fp, "%s", buff);
					in->vars[counter3] = buff[0];
					counter3++; 
				}
				
				counter3 = 0; 
				while(counter3 < in->outputs) { 
					fscanf(fp, "%s", buff);
					in->list[intgray(counter3)] = buff[0];
					counter3++;
				}
				ins[istr++] = in;
				
			}
			else if (strcmp(buff,"AND") == 0 || strcmp(buff,"NOT") == 0 || strcmp(buff,"OR") == 0) {
				char c;
				int counter3 = 0;
				
				in = createIns();
				if (buff[0] == 'O') {
					in->op = OR;
				}
				else if (buff[0] == 'N') {
					in->op = NOT;
				}
				else if (buff[0] == 'A') {
					in->op = AND;
				}
				
				in->vars = (int*)malloc(sizeof(int)*26);
				
				while ((c = fgetc(fp)) != '\n') {
					if (c == ' ') continue;
					in->vars[counter3++] = c;
				}
				in->numPuts = --counter3;
				in->list = (char*)malloc(sizeof(char));
				in->list[0] = in->vars[counter3];
				ins[istr++] = in;
			}
		}
	}
}

void cleans() {
	int i;
	i = 0;
	while(ins[i] != NULL) {
		struct instruct *in = ins[i];
		free(in);
		in = NULL;
		i++; 
	}
}

struct instruct *createIns() {
	struct instruct *in = (struct instruct*)malloc(sizeof(struct instruct));
	return in;
}

void delTable() {
	int i;
	i = 0; 

	while(i < vTable->size) { 
		delNode(vTable->table[i]);
		i++; 
	}
	free(vTable->table);
	vTable->table = NULL;
	free(vTable);
	vTable = NULL;
}

void delNode(struct node *ptr) {
	if (ptr != NULL) {
	}
	else {
		return;
	}
	if (ptr->next == NULL) {
	}
	else {
		delNode(ptr->next);
	}
	free(ptr);
	ptr = NULL;
}

void create(int size) {
	int x;

	vTable = (struct hashtable*) malloc(sizeof(struct hashtable));
	vTable->size = size;
	vTable->table = malloc(sizeof(struct node*) * size);

	x = 0; 
	while(x < size) {
		vTable->table[x] = NULL;
		x++; 
	}
}

void setVar(int value, char letter) {
	int key;
	struct node *ptr;
	struct node *set_node;

	key = letter % vTable->size;
	if (!(vTable->table[key] != NULL && vTable->table[key]->letter == letter)) {
	}
	else {
		vTable->table[key]->value = value;
		return;
	}

	set_node = (struct node*) malloc(sizeof(struct node));
	set_node->value = value;
	set_node->letter = letter;
	set_node->next = NULL;

	if (vTable->table[key] != NULL) {
	}
	else {
		vTable->table[key] = set_node;
		return;
	}
	
	ptr = vTable->table[key];
	
	for(; ptr->next != NULL;) {
		ptr = ptr->next;
	}
	ptr->next = set_node;
}

int getV(char letter) {
	int key = letter % vTable->size;

	struct node *head = vTable->table[key];
	if (head != NULL) {
	}
	else {
		return -1;
	}
	if (head->letter != letter) {
	}
	else {
		return head->value;
	}	
	for(;head != NULL && head->letter != letter;) { 
		head = head->next; 
	}
	if (!(head != NULL && head->letter == letter)) {
	}
	else {
		return head->value;
	}
	return -1;
}
