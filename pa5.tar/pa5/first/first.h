#ifndef _first_h
#define _first_h

/**
 * Enum for all instruct operations
 */	
typedef enum {AND, OR, NOT, MULTIPLEXER, DECODER} OpType; 

/*
 * Instruction struct. Holds all data for an instruct
 *
 * 	op: OpType enum of the operation this instruct does
 * 	vars: array that holds variables
 * 	list: array that holds the variable letters this instruct outputs
 * 	inputs: array for inputs to multiplexer/decoder
 * 	numPuts: count of inputs
 * 	outputs: count of outputs
 *
 */
typedef struct instruct {
	OpType op;
	int *vars;
	char *list;
	int *inputs;
	int numPuts;
	int outputs;
} instruct;

/*
 * Node struct. Acts as a variable, has a variable letter and int value
 *
 * 	letter: char of the letter name for this variable
 * 	value: int value of the variable
 * 	next: next node in the linked list, if there are multiple nodes in this hash key
 *
 */ 
typedef struct node {
	char letter;
	int value;
	struct node *next;
} node;

/**
 * Hashtable struct. Holds array of nodes(variables)
 *	
 *	size: how many elements the table array can hold
 *	table: array of pointers to node structs
 *
 */
typedef struct hashtable {
	int size;
	struct node **table;
} hashtable;

/**
 * Function: evaluate
 * -------------------------
 * Evaluates an instruct, recursively calling itself on other ins if inputs are unresolved variables
 * 
 * 	i: index of the instruct for the instruct array
 *
 */
void evaluate(int i);

/**
 * Function intgray
 * -----------------
 *  Takes a base 10 integer and puts it into gray sequencing
 *
 *	k: int to change to gray sequencing
 *
 *  returns: int in gray sequencing
 */
int intgray(int k);

/**
 * Function: run
 * -------------------
 *  Runs all inputs through instruct set
 *
 */
void run();

/**
 * Function: rInputs
 * --------------------
 *  Reads inputs from file
 *
 *  	fp: FILE pointer with inputs
 *
 */
void rInputs(FILE *fp);

/**
 * Function: read
 * --------------------------
 *  Reads ins from file and creates instruct structs
 *
 *  	fp: FILE pointer with ins
 *
 */
void read(FILE *fp);

/**
 * Function: cleans
 * -----------------
 *  Called after all inputs are completed, frees used memory
 *
 */
void cleans();

/**
 * Function: createIns
 * ----------------------------
 *  Allocates space for and creates an instruct struct
 *
 *  returns: created instruct struct
 *
 */
struct instruct *createIns();

/**
 * Function: delete
 * -----------------------
 *  Deallocates everything in the instruct table
 *
 */
void delTable();

/**
 * Function: deleteN
 * ----------------------
 *  Deallocates a node and all its children
 *
 *  	ptr: pointer to the node needing destroying
 *
 */
void delNode(struct node *ptr);

/**
 * Function: create
 * ----------------------
 *  Creates an empty hashtable
 *  	
 *  	size: how large the table array should be
 *
 */
void create(int size);

/**
 * Function: setVar
 * ----------------
 *  Creates a new node(variable) struct and inserts it into the hash table, or updates the value if it already exists
 *
 *  	letter: variable name
 *	value: int value of variable
 *
 */
void setVar(int value, char letters);

/**
 * Function: getV
 * ----------------
 *  Gets the value of the variable in the hash table
 *
 *  	name: variable letter
 *
 *  returns: value of variable, or -1 if it doesn't exist
 *
 */
int getV(char name);

#endif
